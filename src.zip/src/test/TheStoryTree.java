package test;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class TheStoryTree {

	public static void main(String[] args) {
		
        Scanner in = new Scanner(System.in);        
        int q = in.nextInt();   
        
        for (int i=0; i<q; i++) { 
        	
        	int n = in.nextInt();
        	int edges = n - 1;
        	
        	DFS t = new DFS(n+1); 
        	int[] success = new int[n+1];
        	
        	for (int j=0; j<edges; j++) {
        		
        		int a = in.nextInt();
        		int b = in.nextInt();        		
        		t.addEdge(a, b);
        	}
        	
        	int g = in.nextInt();
        	int k = in.nextInt();
        	
        	for (int j=0; j<g; j++) {
        		
        		//u - v
        		int u = in.nextInt();
        		int v = in.nextInt();

        		String guest1 = v + "-" + u;
        		String guest2 = u + "-" + v;
        		
        		t.dfs1(1, guest1, success);        		
            	t.dfs2(1, guest2, success);        		
            	
        	} 	
        	System.out.println(Arrays.toString(success));
        	
        	int c = 0;
        	for(int j=1;j<success.length; j++) {
        		if (success[j]>=k) {
        			c++;
        		}
        	}
        	//System.out.println(c);
        	System.out.println( convertDecimalToFraction((double)c/n) );
        }
	}
	
	private static String convertDecimalToFraction(double x){
	    if (x < 0){
	        return "-" + convertDecimalToFraction(-x);
	    }
	    double tolerance = 1.0E-6;
	    double h1=1; double h2=0;
	    double k1=0; double k2=1;
	    double b = x;
	    do {
	        double a = Math.floor(b);
	        double aux = h1; h1 = a*h1+h2; h2 = aux;
	        aux = k1; k1 = a*k1+k2; k2 = aux;
	        b = 1/(b-a);
	    } while (Math.abs(x-h1/k1) > x*tolerance);

	    return (int)h1+"/"+(int)k1;
	}
	
	private static class DFS {

		private int v;
		private int s;
		private int[] success;
		private boolean flag;
		private LinkedList<Integer> adj[];
		
		@SuppressWarnings("unchecked")
		public DFS(int v) {
			
			this.v = v;
			adj = new LinkedList[v];
			for (int i = 0; i < v; ++i) {
				adj[i] = new LinkedList<Integer>();
			}
		}	
		
		public void addEdge(int v, int w) {
			adj[v].add(w);
			adj[w].add(v);
		}
		
		public void dfs1(int root, String guest, int[] success) {

			this.flag = true;
			this.success = success;
			
			boolean visited[] = new boolean[v];
			dfsUtil1(root, visited, 0, guest);		
		}
		
		private void dfsUtil1(int v, boolean visited[], int u, String guest) {
			
			visited[v] = true;
			
			String key = v + "-" + u;
			if (guest.equals(key)) {
			
				visited[v] = false;
				visited[u] = true;
				
				for(int i=1;i<visited.length;i++) { 
					if (visited[i]==true) {
						success[i] = success[i] + 1;
					}
				}
				this.flag = false;
				return;
			}
			
			Iterator<Integer> iterator = adj[v].listIterator();
			while (iterator.hasNext() && this.flag) {
				int n = iterator.next();

				if (!visited[n]) {
					dfsUtil1(n, visited, v, guest);
				}
			}		
		}
		
		public void dfs2(int root, String guest, int[] success) {

			this.flag = true;
			this.success = success;
			
			boolean visited[] = new boolean[v];
			dfsUtil2(root, visited, 0, guest);		
		}
		
		private void dfsUtil2(int v, boolean visited[], int u, String guest) {
			
			visited[v] = true;
			
			String key = u + "-" + v;
			if (guest.equals(key)) {
				
				for(int i=1;i<visited.length;i++) {
					if (visited[i]==false) {
						success[i] = success[i] + 1;
					}
				}
				this.flag = false;
				return;
			}
			
			Iterator<Integer> iterator = adj[v].listIterator();
			while (iterator.hasNext() && this.flag) {
				int n = iterator.next();

				if (!visited[n]) {
					dfsUtil2(n, visited, v, guest);
				}
			}		
		}
	}			
}
