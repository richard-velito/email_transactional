package test;

import java.util.ArrayList;
import java.util.Scanner;

public class JavaArrayList {

	public static void main(String[] args) {
		
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        
        ArrayList<ArrayList<Integer>> e = new ArrayList<ArrayList<Integer>>();
        
        for (int i = 0; i < n; i++) { 
        	
        	int n1 = in.nextInt();
        	ArrayList<Integer> e1 = new ArrayList<Integer>();
        	
        	for (int j = 0; j < n1; j++) {
        		e1.add( in.nextInt() );
        	}
        	e.add( e1 );
        }
        
        System.out.println(e);
        
        int q = in.nextInt();
        for (int i = 0; i < q; i++) {
        	
        	int a = in.nextInt();
        	int b = in.nextInt();
        	
        	try {
        		System.out.println(e.get(a-1).get(b-1));
        	} catch (Exception ex) {
        		System.out.println("ERROR!");
        	}
        }
	}
}

