package test;

import java.util.Scanner;

public class IcecreamParlor {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
        int t = in.nextInt();
        
        for (int i = 0; i < t; i++) {         	

        	int m = in.nextInt();
        	int n = in.nextInt();
        	
        	int[] c = new int[n];
        	
        	for (int j = 0; j < n; j++) { 
        		c[j] = in.nextInt() ;
        	}
        	
        	calculate(c, m);
        }
	}
	
	public static void calculate(int[] c, int m) {
		
		for (int i=0;i<c.length;i++) {
			for (int j=i+1;j<c.length;j++) {
				if ((c[i]+c[j])==m) {
					//System.out.println(" i :" + i+1 + ", j : "+ j+1);
					System.out.println( (i+1) + " "+ (j+1));					
					return;
				}
			}	
		}
	}
	
	private static int binarySearch(int arr[], int val) {
		
		if(arr == null || arr.length == 0) {
			return -1;
		}
		int low = 0;
	    int high = arr.length - 1;

	    while (low < high) {
	        int mid = low + (high - low) / 2;

	        if (arr[mid] == val) {
	            return mid;
	        } else if (arr[mid] < val) {
	            low = mid + 1;
	        } else {
	            high = mid - 1;
	        }
	    }
	    return arr[low] == val ? low : -1;
	}		
	
}
