package test;

import java.util.*;

public class Main {

    public static String isValid(String s){
    	
    	boolean flag = true;
    	HashMap<String, Integer> e = new HashMap<String, Integer>();
    	
    	for( int i=0;i<s.length();i++ ) { 	
    		
    		String key = s.substring(i, (i+1));
    		if ( !e.containsKey(key) ) {    			
    			e.put( key, 1);
    		} else {
    			e.put( key, e.get(key)+1 );
    		}
    	} 
    	
    	HashMap<Integer, Integer> e1 = new HashMap<Integer, Integer>();    	
    	for (int v : e.values()){
	
    		if ( !e1.containsKey(v) ) {    			
    			e1.put( v, 1);
    		} else {
    			e1.put( v, e1.get(v)+1 );
    		}
    	}

    	if (e1.size()>2) {
    		flag = false;
    	} else if (e1.size()!=1) {

    		int c = 0;
			for (Map.Entry<Integer, Integer> entry : e1.entrySet()) {
    			
    			if (entry.getKey()!=1) {
    				c += entry.getKey() * entry.getValue();
    			}
    		}
			if (c!=s.length()-1) {
				flag=false;
			}
    	}
    	
    	System.out.println(e);
    	System.out.println(e1);
    	
    	if (flag) 
    		return "YES";
    	else
    		return "NO";
    }

    public static void main(String[] args) {
    	
        Scanner in = new Scanner(System.in);
        String s = in.next();
        System.out.println( isValid(s) );        
    }	
	
    /*
    public static void main(String[] args) { 
        String anotherPalindrome = "Niagara. O roar again!"; 
    	char aChar = anotherPalindrome.charAt(3);
    	
    	for( int i=0;i<anotherPalindrome.length();i++ ) { 	    		
    		System.out.println(anotherPalindrome.charAt(i));
    	} 
    	
    	/*
    	Scanner in = new Scanner(System.in);
        int s = in.nextInt();
        int[] ar = new int[s];
        for(int i=0;i<s;i++){
        	ar[i]=in.nextInt(); 
        }       
    }
    */
    
    public static void grading(int[] ar) {
    	
    	for(int i=0;i<ar.length;i++) {
    	
    		int n = ar[i];
    		if (n<38) 
    			System.out.println(n);
    		else {
    			
    			int next = (( (n/5)+1 ) * 5) ;
    			if (next-n<3)
    				System.out.println(next);
    			else
    				System.out.println(n);	
    		}
    	}
    }
    
    public static void closetsNumbers(int[] ar) {
    	
    	List<Integer> elements = new ArrayList<Integer>();
    	Arrays.sort(ar);  
    	
    	int minDiff = 100000000;
     	//int currDif = ar[0]-ar[1];
     	
    	for(int i=0;i<(ar.length-1);i++){
    		
    		int currDif = Math.abs(ar[i]-ar[i+1]);
    		if (currDif < minDiff) {
    			elements.clear();
				elements.add(ar[i]);
				elements.add(ar[i+1]);
				minDiff = currDif;
    		} else if (currDif == minDiff) {
    			elements.add(ar[i]);
				elements.add(ar[i+1]);
    		}
    	}

    	for(int e:elements) {
    		System.out.print(e+" ");
    	}
	}
    
    public static void quickSort1(int[] ar) {
    	
    	int p = ar[0];
    	int[] l = new int[ar.length];
    	int lc = 0;
    	int[] e = new int[ar.length];
    	int ec = 0;
    	int[] r = new int[ar.length];
    	int rc = 0;
    	
    	for(int i=0;i<ar.length;i++) {
    		if (ar[i]<p) {
    			l[lc] = ar[i];
    			lc++;
    		} else if (ar[i]>p) {    			
    			r[rc] = ar[i];
    			rc++;
    		} else {    			
    			e[ec] = p;
    			ec++;
    		}
    	}
    	printArray(l, lc);
    	printArray(e, ec);
    	printArray(r, rc);
    }
    
    private static void printArray(int[] ar, int a) {
    	for(int i=0;i<ar.length;i++) {
    		if (i<a)
    			System.out.print(ar[i]+" ");
    	}
   }
    
   private static void printArray(int[] ar) {
    	for(int i=0;i<ar.length;i++) {
    		System.out.println(ar[i]);
    	}
   }
	
    public static void insertIntoSorted(int[] ar) {

    	int l = ar.length;
    	int rMost = ar[ (l-1) ];

		for(int i=(l-1);i>=0;i--) {
			
			if ( i>0 && rMost<=ar[i]) {
				ar[i] = ar[i-1];
			} 
			if (rMost>ar[i] || i==0) {
				ar[i]=rMost;
				break;
			}
			printArray(ar, ar.length);
		}
		printArray(ar, ar.length);
    }
}
