package test;

import java.util.Arrays;
import java.util.Scanner;

public class MarcsCakewalk {

    public static void main(String[] args) {
    
    	Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int[] arr = new int[n];
        for(int arr_i = 0; arr_i < n; arr_i++){
            arr[arr_i] = in.nextInt();
        }
    
        Arrays.sort(arr);
        
        long cal = 0;
        int j = 0;
        for(int i = n-1; i>=0; i--) {
        	
        	System.out.println(arr[i] + "-" + (int)(Math.pow(2, j)) );
        	cal += ( arr[i] * (long)(Math.pow(2, j)) );
        	j++;
        }
    
        
        System.out.println(cal);
    }		
	
}
