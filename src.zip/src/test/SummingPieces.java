package test;

import java.util.Arrays;
import java.util.Scanner;

public class SummingPieces {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
        int n = in.nextInt();        
        long[] c = new long[n];
    	
    	for (int i = 0; i < n; i++) { 
    		c[i] = in.nextInt() ;
    	}
    	
    	System.out.println(operate(0, c));
	}

	public static long operate(long s, long[] c) {
		
		//System.out.println("SUM: " + s + ", array: " + Arrays.toString(c));
		
		if (c.length==0)
			return 0;
		
		if (c.length==1) {
			return s+c[0];
		}
		
		long globalSum = 0;
		long sum = s;
		
		for(int i=0; i<c.length; i++) {			
			
			sum += c[i];
			
			if (c.length-(i+1)>0) {
				globalSum += operate((sum*(i+1)), Arrays.copyOfRange(c, (i+1),c.length) ) ;
			} else { 
				globalSum += (sum*(i+1));
			}
		}

		System.out.println("SUM: " + s + ", values: " + Arrays.toString(c) + ", RESULT :" + globalSum);
		return globalSum;
	}	
	
	public static long operate(long[] c) {
		
		System.out.println(Arrays.toString(c));
		
		if (c.length==0)
			return 0;
		
		if (c.length==1) 
			return c[0];
		
		long globalSum = 0;
		long sum = 0;
		
		for(int i=0; i<c.length; i++) {			
			
			if (c.length-(i+1)>0) {
				globalSum += operate( Arrays.copyOfRange(c, (i+1),c.length) ) ;
			}
			
			sum += c[i];
			globalSum += (sum*(i+1)) * (1); // falta un elemento
		}
		
		System.out.println("Return : " + globalSum);
		return globalSum;
	}
	
}
