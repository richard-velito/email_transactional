package test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class SherlockAndValidString {
	
    public static String isValid(String s){

    	HashMap<String,Integer> cMap = new HashMap<String,Integer>();
    	
    	for (int i = 0; i < s.length(); i++){
    		
    	    String c = String.valueOf( s.charAt(i) ); 
    	    
    	    if (cMap.containsKey(c)) {
    	    	cMap.put(c, ( cMap.get(c)+1 ) );
    	    } else{
    	    	cMap.put(c, 1);
    	    }
    	}
    	
    	Integer[] v = cMap.values().toArray(new Integer[0]);
    	Arrays.sort(v);    	
    	HashMap<Integer,Integer> vMap = new HashMap<Integer,Integer>();
    	for (int i = 0; i < v.length; i++) {
    		
    	    if (vMap.containsKey(v[i])) {
    	    	vMap.put(v[i], ( vMap.get(v[i])+1 ) );
    	    } else{
    	    	vMap.put(v[i], 1);
    	    }
    	}
    	
    	System.out.println(vMap);
    	if (vMap.size()!=1) {
    		
    		if (vMap.size()>2) {
    			return "NO";
    		} else {

    			Integer[] values = vMap.values().toArray(new Integer[0]);
    			Integer[] keys = vMap.keySet().toArray(new Integer[0]);
    			
    			if (keys[0]==1 && values[0]==1) {
    				return "YES";
    			}
    			if (keys[1]==1 && values[1]==1) {
    				return "YES";
    			}
    			
    			if (Math.abs( keys[0]-keys[1] )>1) {
    				return "NO";
    			}
    			if (values[0]>1 && values[1]>1) {
    				return "NO";
    			}
    			return "YES";
    			
    		}
    	} else {
    		return "YES";
    	}
    }

    public static void main(String[] args) {
    	
        Scanner in = new Scanner(System.in);
        String s = in.next();
        String result = isValid(s);

        System.out.println(result);
    }
}
