package test;

public class GraphTheory {

    public static void main(String[] args) {
    
    	
    	BFS g = new BFS(9);
		g.addEdge(0, 1);
		g.addEdge(0, 5);
		g.addEdge(0, 7);
		g.addEdge(1, 2);
		g.addEdge(5, 6);
		g.addEdge(2, 8);
		g.addEdge(6, 8);
		g.addEdge(2, 3);
		g.addEdge(4, 3);
		g.addEdge(4, 6);
		g.addEdge(4, 8);

		//g.printBFS();
		System.out.println("Following is Breadth First Traversal (starting from vertex 0): ");
		g.bfs(2);
		
		/*
		DFS d = new DFS(9);
		d.addEdge(0, 1);
		d.addEdge(0, 5);
		d.addEdge(0, 7);
		d.addEdge(1, 2);
		d.addEdge(5, 6);
		d.addEdge(2, 8);
		d.addEdge(6, 8);
		d.addEdge(2, 3);
		d.addEdge(2, 7);
		d.addEdge(4, 3);
		d.addEdge(4, 6);
		d.addEdge(4, 8);
		System.out.println("Following is Depth First Traversal: ");
		d.dfs();
		*/
    }
    
}
