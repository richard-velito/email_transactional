package test;

import java.util.Arrays;
import java.util.Scanner;

public class LuckBalance {

    public static void main(String[] args) {
        
    	Scanner in = new Scanner(System.in);

    	int n = in.nextInt();
    	int l = in.nextInt();
        
    	int[] arr = new int[n];
        int luck = 0;
        
        for(int i = 0; i < n; i++){
            
        	int luckq = in.nextInt();
        	int important = in.nextInt();
        	
        	if (important == 0) {
        		luck += luckq; 
        	} else {
        		arr[i] = luckq;
        	}
        }
        
        System.out.println(luck + calculate(arr, l));
    }	
    
    public static int calculate(int[] arr, int l) {
    	
    	int luck = 0;
    	int j = 1;
    	Arrays.sort(arr);
    	
    	for ( int i = arr.length-1; i>=0; i-- ) {
    	
    		if (j<=l) {
    			luck += arr[i];
    		} else {
    			luck -= arr[i];
        	}
    		j++;
    	}
    	
    	return luck;
    }
	
}
