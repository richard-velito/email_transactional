package test;

import java.util.Scanner;

public class EqualDP {

    public static void main(String[] args) {
    	
        Scanner s = new Scanner(System.in);
        int t = s.nextInt();
        
        for (int j = 0; j < t; ++j) {
        	
        	int n = s.nextInt();
        	int[] arr = new int[n];
        	int max = -1;
        	
        	for (int i = 0; i < n; ++i) {
        		
        		arr[i] = s.nextInt();
        		max = Math.max( arr[i], max );
        	}        	
        	equal(arr, max);
        }
    }
    
    public static void equal(int[] arr, int max) {
    	
    	int n = arr.length;
    	for (int i = 0; i < n; ++i) {
    		
    	}
    }
}
