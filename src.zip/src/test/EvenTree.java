package test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class EvenTree {

	public static void main(String[] args) {
		
        Scanner in = new Scanner(System.in);
        int m = in.nextInt();
        int n = in.nextInt();
        
        HashMap<Integer, Integer> e = new HashMap<Integer, Integer>();
        
        for (int i = 0; i < n; i++) { 
        	int a = in.nextInt();
            int b = in.nextInt();
        	e.put(a, b);
        }

        for (Integer key : e.keySet()) {
        	
        }
        
        //System.out.println( g.dfs() );
	}
	
	private static class DFS {

		private int v;
		private int g = 0;
		private LinkedList<Integer> adj[];
		
		@SuppressWarnings("unchecked")
		public DFS(int v) {
			
			this.v = v;
			adj = new LinkedList[v];
			for (int i = 0; i < v; ++i) {
				adj[i] = new LinkedList<Integer>();
			}
		}	

		public void removeEdge(int v, int w) {
			adj[v].remove(w);
			adj[w].remove(v);
		}
		
		public void addEdge(int v, int w) {
			adj[v].add(w);
			adj[w].add(v);
		}
		
		public boolean dfs() {

			g=0;
			boolean visited[] = new boolean[v];

			for (int i = 1; i < v; ++i) {
				if (!visited[i]) {
					g=0;
					dfsUtil(i, visited);
					if (g%2!=0)
						return false;
				}
			}
			return true;
		}
		
		private void dfsUtil(int v, boolean visited[]) {
			
			g++;
			
			visited[v] = true;

			Iterator<Integer> iterator = adj[v].listIterator();
			while (iterator.hasNext()) {
				int n = iterator.next();

				if (!visited[n]) {
					dfsUtil(n, visited);
				}
			}		
		}
	}		
}
