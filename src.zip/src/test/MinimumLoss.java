package test;

import java.util.Scanner;

public class MinimumLoss {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        
        long[] c = new long[n];
        for (int i = 0; i < n; i++) {  
        	c[i] = in.nextLong();
        }
        
        calculate(c);
    }
	
	public static void calculate(long[] c) {
		
		long minGlobal = 10000000;
		long min = 10000000;
		
		int n = c.length-2;
		for(int i=n-1; i>=0; i--) {
			
			min = Math.min( min, c[i+1] );
			minGlobal = Math.min(minGlobal, min);
		}
		
		System.out.println(minGlobal);
	}
	
	public static long min(long[] c, int s) {
		
		long r = 10000000;
		for(int i=s+1; i<c.length; i++) {
			
			if ((c[s]-c[i])>0) {
				r = Math.min(r, (c[s]-c[i])  );
			}
		}
		return r;
	}
	
}
