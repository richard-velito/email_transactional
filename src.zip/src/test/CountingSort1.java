package test;

import java.util.Scanner;

public class CountingSort1 {

	public static void main(String[] args) {
		
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        
        int[] e = new int[100];
        
        for (int i = 0; i < n; i++) { 

        	e[in.nextInt()]++;
        }
        
        
        for(int i=0;i<n;i++) {
        	if (e[i]>0) {
        		for(int j=0;j<e[i];j++) {
        			System.out.print(i + " ");	
        		}
        	}
        		//System.out.print(e[i] + " ");	
        }
	}
}
