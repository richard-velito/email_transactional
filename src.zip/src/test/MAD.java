package test;

import java.util.Arrays;
import java.util.Scanner;

public class MAD {

    public static int minimumAbsoluteDifference(int n, int[] arr) {
        
    	int min = 999999;
    	
    	Arrays.sort(arr);
    	
    	for (int i = 1; i < n; i++) {
    		
    		int c = Math.abs( arr[i] - arr[i-1] );
    		//System.out.println(c);
    		
    		min = Math.min(min, c);
    		
    	}
    	
    	return min;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int[] arr = new int[n];
        for(int arr_i = 0; arr_i < n; arr_i++){
            arr[arr_i] = in.nextInt();
        }
        int result = minimumAbsoluteDifference(n, arr);
        System.out.println(result);
        in.close();
    }	
	
}
