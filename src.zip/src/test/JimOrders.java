package test;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

public class JimOrders {

	public static void main(String[] args) {
		
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        
        HashMap<Integer, Integer> e = new HashMap<Integer, Integer>();
        
        for (int i = 0; i < n; i++) { 
        	int a = in.nextInt();
            int b = in.nextInt();

            e.put((i+1), (a+b));
        }
        
	    // JAVA 8
	    Map e2 = e.entrySet().stream()
        	.sorted(Map.Entry.<Integer, Integer>comparingByValue())
        	.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                    (oldValue, newValue) -> oldValue, LinkedHashMap::new));        
        
	    e2.forEach((k,v)->System.out.print(k + " "));
	}
}
