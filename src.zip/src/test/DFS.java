package test;

import java.util.Iterator;
import java.util.LinkedList;

public class DFS {

	private int v;
	private LinkedList<Integer> adj[];
	
	@SuppressWarnings("unchecked")
	public DFS(int v) {
		
		this.v = v;
		adj = new LinkedList[v];
		for (int i = 0; i < v; ++i) {
			adj[i] = new LinkedList<Integer>();
		}
	}	
	
	public void addEdge(int v, int w) {
		adj[v].add(w);
		adj[w].add(v);
	}
	
	public void dfs() {

		boolean visited[] = new boolean[v];
		for (int i = 0; i < v; ++i) {
			if (!visited[i]) {
				dfsUtil(i, visited);
			}
		}
	}	
	
	private void dfsUtil(int v, boolean visited[]) {
		
		visited[v] = true;
		System.out.print(v + " ");

		Iterator<Integer> iterator = adj[v].listIterator();
		while (iterator.hasNext()) {
			int n = iterator.next();

			if (!visited[n]) {
				dfsUtil(n, visited);
			}
		}		
	}
}
