package test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class Practice {

	public static void main(String[] args) {
		
		//List<String> l = new ArrayList<String>();
		//l.add("pep34");
		//l.add("pep1");
		//l.add("pep2");
		
		//Collections.sort(l);
		
		//System.out.println(l);
		
		//"demo".toCharArray();
		
		//int ascii = 'z';
		//System.out.println(ascii);

		test("abc1abcd3abc");
		test("qaz1qaz2qa2bgt3bgt2");
	}
	
	private static void test(String s) {
		
		Set<String> unique = new HashSet<String>();
		StringBuilder seq = new StringBuilder();
		
		for(char k : s.toCharArray()) {
			
			String element = String.valueOf(k);
			
			if (seq.indexOf(element)!=-1) {
			
				int indexOf = seq.indexOf(element);
				
				String part = seq.substring(indexOf+1);
				seq = new StringBuilder();
				seq.append(part);				
			} 

			seq.append(element);
			
			if (seq.length()>2) {
				
				String found = seq.toString();
				unique.add(found);	
				
				for(int i=0; i<seq.length()-3;i++) {
					found = seq.substring(i,i+3);
					unique.add(found);	
				}
			}
		}

		for(String key : unique) {
			
			int p = s.split(key).length;
			if (p>2) {
				System.out.println(key);
			}
		}
		
		System.out.println(unique);					
	}
	
	private static void testMap() {
		
		Map<String, Integer> e = new TreeMap<String, Integer>();
		e.put("a", 1);
		e.put("e", 3);
		e.put("b", 4);
		e.put("c", 2);
			
		// JAVA 7
		Map<String, Integer> e1 = sortByValue(e);
		
		System.out.println(e1);
		
	    for(Map.Entry<String, Integer> entry : e1.entrySet()) {
	        System.out.println(entry.getKey() + ": " + entry.getValue());
	    }
	    
	    // JAVA 8
	    Map e2 = e.entrySet().stream()
        	.sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
        	.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                    (oldValue, newValue) -> oldValue, LinkedHashMap::new));
	    
	    System.out.println(e2);
	    
	    Iterator i = e2.entrySet().iterator();
	    while(i.hasNext()) {
	    	Map.Entry me = (Map.Entry)i.next();
	        System.out.println(me.getKey() + ": " + me.getValue());
	    }
	}
	
    private static Map<String, Integer> sortByValue(Map<String, Integer> unsortMap) {

        List<Map.Entry<String, Integer>> list =
                new LinkedList<Map.Entry<String, Integer>>(unsortMap.entrySet());

        Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
            public int compare(Map.Entry<String, Integer> o1,
                               Map.Entry<String, Integer> o2) {
                return (o2.getValue()).compareTo(o1.getValue());
            }
        });

        Map<String, Integer> sortedMap = new LinkedHashMap<String, Integer>();
        for (Map.Entry<String, Integer> entry : list) {
            sortedMap.put(entry.getKey(), entry.getValue());
        }
        return sortedMap;
    }
}
