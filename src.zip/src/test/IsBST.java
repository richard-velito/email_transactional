package test;

public class IsBST {

	public static void main(String[] args) {
	
		Node n1 = new Node();
		n1.data = 3;
		
		Node n2 = new Node();
		n2.data = 2;
		
		Node n21 = new Node();
		n21.data = 1;
		n2.left = n21;

		Node n22 = new Node();
		n22.data = 4;
		n2.right = n22;
		
		Node n3 = new Node();
		n3.data = 4;
		
		n1.left = n2;
		n1.right = n3;
		
		System.out.println(  checkBST(n1) );		
	}
	
    public static boolean checkBST(Node root) {
        
    	boolean response = true;
    	
    	if (root.left!=null) {
    		if ( root.left.data<root.data ) {
    			response = checkBST(root.left);
    		} else {
    			response = false;
    		}
    	}
    	
    	if (response) {
	    	if (root.right!=null) {
	    		if ( root.right.data>root.data ) {
	    			response = checkBST(root.right);
	    		} else {
	    			response = false;
	    		}
	    	}
    	}
    	return response;
    }
	
	private static class Node {
		public int data;
        public Node left;
        public Node right;
     }
}


