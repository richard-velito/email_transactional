package test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class TorqueDevelopment {

	public static void main(String[] args) {
	
        Scanner in = new Scanner(System.in);
        int q = in.nextInt();

        for (int a0 = 0; a0 < q; a0++) { 
        	
        	int n = in.nextInt();
            int m = in.nextInt();
            long x = in.nextLong();
            long y = in.nextLong();       

            DFS g = new DFS(n+1);
            
            for (int a1 = 0; a1 < m; a1++) {

            	int v = in.nextInt();
                int w = in.nextInt();
                
                g.addEdge(v, w);                
            }
            
            g.dfs();
            System.out.println(g.getGroups());
            System.out.println( getMinimalCost(g.getGroups(), x, y) );
        }
	}
	
	public static long getMinimalCost( HashMap<Integer,Integer> groups, long cl , long cr) {
		
		long minimalCost = 0;
        
        for (Integer key : groups.keySet()) {
        	
        	int nodes = groups.get(key);
        	int vertex = nodes-1;
        	
        	if ( (cl*nodes) > (cr*vertex) + cl ) {
        		minimalCost += (cr*vertex) + cl; 
        	} else {
        		minimalCost += (cl*nodes);
        	}
    	}
		return minimalCost;
	}
	
	private static class DFS {

		private int v;
		private int index = 0;
		private int g = 0;
		private HashMap<Integer,Integer> groups = new HashMap<Integer,Integer>();
		private LinkedList<Integer> adj[];
		
		@SuppressWarnings("unchecked")
		public DFS(int v) {
			
			this.v = v;
			adj = new LinkedList[v];
			for (int i = 0; i < v; ++i) {
				adj[i] = new LinkedList<Integer>();
			}
		}	
		
		public void addEdge(int v, int w) {
			adj[v].add(w);
			adj[w].add(v);
		}
		
		public void dfs() {

			boolean visited[] = new boolean[v];
			for (int i = 1; i < v; ++i) {
				if (!visited[i]) {
					index++;
					g=0;
					dfsUtil(i, visited);
				}
			}
		}
		
		private void dfsUtil(int v, boolean visited[]) {
			
			g++;
			groups.put(index, g);
			
			visited[v] = true;
			//System.out.print(v + " ");

			Iterator<Integer> iterator = adj[v].listIterator();
			while (iterator.hasNext()) {
				int n = iterator.next();

				if (!visited[n]) {
					dfsUtil(n, visited);
				}
			}		
		}
		
		public HashMap<Integer,Integer> getGroups() {
			return groups;
		}
	}
}
