package test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class JourneyMoon {

	public static void main(String[] args) {
		
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int p = in.nextInt();

        DFS g = new DFS(n);        
        for (int i = 0; i < p; i++) { 
        	
        	int a = in.nextInt();
            int b = in.nextInt();
            
            g.addEdge(a, b);
        }
        g.dfs();
        System.out.println(operate(g.getItems()));
	}
	
	private static long operate(ArrayList<Integer> items) {
		
		long r = 0;
		long sum = 0;
		
		for(int i=0;i<items.size();i++) {
			r += sum*items.get(i);
			sum += items.get(i);
		}
		
		//for(int i=0;i<items.size();i++) {
			//	for(int j=i+1;j<items.size();j++) {
				//r += items.get(i)*items.get(j);
			//	}
		//}
		return r;
	}
	
	private static class DFS {

		private int v;
		private int g = 0;
		private ArrayList<Integer> items = new ArrayList<>();
		private LinkedList<Integer> adj[];
		
		@SuppressWarnings("unchecked")
		public DFS(int v) {
			
			this.v = v;
			adj = new LinkedList[v];
			for (int i = 0; i < v; ++i) {
				adj[i] = new LinkedList<Integer>();
			}
		}	
		
		public void addEdge(int v, int w) {
			adj[v].add(w);
			adj[w].add(v);
		}
		
		public void dfs() {

			boolean visited[] = new boolean[v];
			for (int i = 0; i < v; ++i) {
				if (!visited[i]) {
					g=0;
					dfsUtil(i, visited);
					items.add(g);
				}
			}
		}
		
		private void dfsUtil(int v, boolean visited[]) {
			
			g++;
			
			visited[v] = true;

			Iterator<Integer> iterator = adj[v].listIterator();
			while (iterator.hasNext()) {
				int n = iterator.next();

				if (!visited[n]) {
					dfsUtil(n, visited);
				}
			}		
		}
		
		public ArrayList<Integer> getItems() {
			return items;
		}
	}	
}
