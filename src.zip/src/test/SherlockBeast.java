package test;

import java.util.Scanner;

public class SherlockBeast {

	public static void calculate(int number) {
		
		long n3 = -1;
		long n5 = -1;
		
		if (number>2) {
			
			for ( int i=number;i>0; i--) {
				
				if ( i%3 == 0) {
					if ( (number-i)%5 == 0 ) {						
						n5 = i;
						n3 = (number-i);
						break;
					}
				}
				
				if ( i%5 == 0 ) {
					if ( (number-i)%3 == 0) {
						
						n5 = (number-i);
						n3 = i;
					}
				}
			}
		} 

		//System.out.println("n5:" + n5 + "-n3:" + n3);
		
		if (n5==-1 && n3==-1) {
			
			System.out.print("-1");
		} else {
		
			for(int i=0;i<n5;i++) {
				System.out.print("5");
			}
			for(int j=0;j<n3;j++) {
				System.out.print("3");
			}
		}
	}
	
    public static void main(String[] args) {
    
    	Scanner in = new Scanner(System.in);
        int n = in.nextInt();        
        int[] arr = new int[n];
        for(int i = 0; i < n; i++){
            arr[i] = in.nextInt();
        }    	
    	
		for( int i=0 ;i<arr.length ;i++ ) {
			
			calculate(arr[i]);
			System.out.println("");
		}
    }
}
