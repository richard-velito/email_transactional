package test;

import java.util.HashMap;
import java.util.LinkedList;

public class AdjacencyList {

	private final LinkedList< HashMap<Integer, Integer> >[] adjacencyList;
	
	public AdjacencyList(int vertex) {
		
		adjacencyList = (LinkedList< HashMap<Integer, Integer> >[]) new LinkedList[vertex];
		
		for (int i = 0; i < adjacencyList.length; ++i) {
            adjacencyList[i] = new LinkedList<>();
        }
	}
	
    public void addEdge(int startVertex, int endVertex, int weight) {
    	
    	HashMap<Integer, Integer> e = new HashMap<>(endVertex + 1, weight);
    	adjacencyList[startVertex].add(e);
    }
    
    public int getNumberOfVertices() {
        return adjacencyList.length;
    }

    public int getNumberOfEdgesFromVertex(int startVertex) {
        return adjacencyList[startVertex].size();
    }
    
    // Returns a copy of the Linked List of outward edges from a vertex
    public LinkedList< HashMap<Integer, Integer> > getEdgesFromVertex(int startVertex) {
        LinkedList< HashMap<Integer, Integer> > edgeList
                            = (LinkedList< HashMap<Integer, Integer> >) new LinkedList(adjacencyList[startVertex]);

        return edgeList;
    }

    public void printAdjacencyList() {
        int i = 0;

        for (LinkedList< HashMap<Integer, Integer> > list : adjacencyList) {

        	System.out.print("adjacencyList[" + (i + 1) + "] -> ");
        	
            for (HashMap<Integer, Integer> edge : list) {
            	
            	for (Integer key : edge.keySet()) {
            		System.out.print(key + "(" + edge.get(key) + ") ");
            	}
            }

            ++i;
            System.out.println();
        }
    }

    public boolean removeEdge(int startVertex, HashMap<Integer, Integer> edge) {
        return adjacencyList[startVertex - 1].remove(edge);
    }

    public boolean hasEdge(int startVertex, int endVertex, int weight) {
        return adjacencyList[startVertex].contains(new HashMap<>(endVertex, weight));
    }
}
