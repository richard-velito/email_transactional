package test;

import java.util.Scanner;

public class GoToTheRapture {

	
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		int e = in.nextInt();
        
		DijkstraAlgorithm da = new DijkstraAlgorithm( (n+1) );

		int w[][] = new int[(n+1)][(n+1)];
		for (int i = 0; i < e; i++) {         	

        	int a = in.nextInt();
        	int b = in.nextInt();
        	int c = in.nextInt();

        	w[a][b] = c;
        	w[b][a] = c;
        }
		
		da.dijkstra(w, 1);
    }	
	
	private static class DijkstraAlgorithm {
		
		private int v;

		public DijkstraAlgorithm(int v) {
			this.v = v;
		}
		
		public int minDistance(int[] dist, boolean[] sptSet) {

			int min = Integer.MAX_VALUE;
			int minIndex = -1;

			for(int i = 1; i < this.v; i++) {
				if(!sptSet[i] && dist[i] <= min) {
					min = dist[i];
					minIndex = i;
				}
			}
			return minIndex;
		}
		
		public void dijkstra(int[][] graph, int src) {

			int[] dist = new int[this.v];
			boolean[] sptSet = new boolean[this.v];

			for(int i = 0; i < this.v; i++) {
			
				dist[i] = Integer.MAX_VALUE;
				sptSet[i] = false;
			}

			dist[src] = 0;

			for (int count = 0; count < this.v-1; count++) {

				int u = minDistance(dist, sptSet);
				sptSet[u] = true;

				for (int i = 0; i < this.v; i++) {

					int d = 0;
					if ( graph[u][i]-dist[u]>0 ) {
						d = graph[u][i]-dist[u];
					} 					
					
					if (!sptSet[i] && graph[u][i] != 0 
							&& dist[u] != Integer.MAX_VALUE 
							&& (dist[u]+d) < dist[i]) {

						dist[i]	 = dist[u]+d;
					}
				}
			}

			if (dist[ (this.v-1) ] == Integer.MAX_VALUE) {
				System.out.println( "NO PATH EXISTS" );
			} else {
				System.out.println( dist[ (this.v-1) ] );
			}
		}
	}
}
