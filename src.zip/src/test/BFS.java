package test;

import java.util.Iterator;
import java.util.LinkedList;

public class BFS {

	private int v;
	private LinkedList<Integer> adj[];
	
	@SuppressWarnings("unchecked")
	public BFS(int v) {
		
		this.v = v;
		adj = new LinkedList[v];
		for (int i = 0; i < v; ++i) {
			adj[i] = new LinkedList<Integer>();
		}
	}
	
	public void addEdge(int v, int w) {
		adj[v].add(w);
		adj[w].add(v);
	}
	
	public void printBFS() {
		
		for(int i=0;i<adj.length;i++) {
			System.out.println(adj[i]);	
		}
	}
	
	public void bfs(int source) {

		boolean visited[] = new boolean[v];

		LinkedList<Integer> queue = new LinkedList<Integer>();

		visited[source] = true;
		queue.add(source);

		while (queue.size() != 0) {

			source = queue.poll();
			System.out.print(source + " ");

			Iterator<Integer> iterator = adj[source].listIterator();

			while (iterator.hasNext()) {
				int n = iterator.next();

				if (!visited[n]) {
					visited[n] = true;
					queue.add(n);
				}
			}
		}
	}
	
}
