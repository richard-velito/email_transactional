package test;

import java.util.Arrays;
import java.util.Scanner;

public class MarkToys {

	
    public static void main(String[] args) {
        
    	Scanner in = new Scanner(System.in);
    	int n = in.nextInt();
    	int k = in.nextInt();
        
        int[] arr = new int[n];
        for(int arr_i = 0; arr_i < n; arr_i++){
            arr[arr_i] = in.nextInt();
        }
    
        Arrays.sort(arr);
     
        int sum = 0;
        int acu = 0;
        for(int i = 0; i < n; i++){
            
        	sum += arr[i];
        	if (sum>k) {
        		break;
        	}
        	acu++;
        }
        
        System.out.println(acu);
    }
}
